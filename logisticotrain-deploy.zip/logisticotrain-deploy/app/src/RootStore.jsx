import { createContext } from 'react';

const RootStore = createContext();

export default RootStore;
